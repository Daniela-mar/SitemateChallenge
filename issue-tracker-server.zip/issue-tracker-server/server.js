const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());

let issues = [
    { id:1, title: "Static Issue", description: "This is a static issue description"}
];

app.post('/api/issues', (req, res) =>
{
    const newIssue = req.body;

    if (!newIssue.title || ! newIssue.description) {
        return res.status(400).json({ message: 'Title and description required.'});
    }

    newIssue.id = issues.length + 1; 
    issues.push(newIssue);

    res.status(201).json({
        message: 'Issue created', issue: newIssue 
    });

    app.get('/api/issues/:id?', (req, res) => {
        const issueId = parseInt(req.params.id, 10);

        if(!issueId) {
            return res.status(200).json(issues);
        }

        const foundIssue = issues.find(issue.id === issueId);

        if (!foundIssue) {
            return res.status(404).json({message: `Issue with ID ${issueId} not found.`});
        }

        res.status(200).json(foundIssue);
    });


    app.put('/api/issues/:id', (req, res) => {
        const issueId = parseInt(req.params.id, 10);
        const updatedIssue = req.body;

        const index = issues.findIndex(issue => issue.id === issueId);

        if(index === -1) {
            return res.status(404).json({message: `Issue with Id ${issueId} not found`});
        }

        if (!updatedIssue.title || ! updatedIssue.description) {
            return res.status(400).json({message: 'Title and description are required'});

        }

        issues[index] = {id: issueId, ...updatedIssue};
    res.status(200).json({message: 'Issue updated', issue: issues[index] });  
  });

    app.delete('/api/issues/:id', (req, res) => {
        const issueId = parseInt(req.params.id, 10);

        const index = issues.findIndex(issue => issue.id === issueId);

        if ( index === -1) {
            return res.status(404).json({message: `Issue with Id ${issueId} not found`});
     
        }

        const deletedIssue = issues.splice(index, 1);
            res.status(200).json({message: `Issue with Id ${issueId} deleted`, 
        issue: deletedIssue});

    });

    const PORT = 4000;
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
});